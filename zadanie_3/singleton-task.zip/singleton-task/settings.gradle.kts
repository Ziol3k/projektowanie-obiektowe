rootProject.name = "singleton-task"
